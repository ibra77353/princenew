import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { PageHeader, LoadingState, EmptyState, ConfirmDialog } from "@/components/ui-shared";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { formatDateTime } from "@/lib/format";
import { DatabaseBackup, Download, Upload, Trash2, RotateCcw } from "lucide-react";

export default function Backup() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [restoreItem, setRestoreItem] = useState(null);
  const [restoreLoading, setRestoreLoading] = useState(false);
  const [downloading, setDownloading] = useState(null);

  const load = async () => {
    setLoading(true);
    try { setItems(await base44.entities.Backup.list("-created_date", 100)); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const create = async () => {
    setCreating(true);
    try {
      const res = await base44.functions.invoke("createBackup", {});
      if (res.data?.error) { alert(res.data.error); return; }
      load();
      alert("تم إنشاء النسخة الاحتياطية بنجاح");
    } catch (e) { alert(e.message); } finally { setCreating(false); }
  };

  const remove = async (b) => {
    if (!confirm("حذف هذه النسخة الاحتياطية؟")) return;
    await base44.entities.Backup.delete(b.id);
    load();
  };

  const download = async (b) => {
    setDownloading(b.id);
    try {
      // For private files, generate a signed URL; for legacy public files, use file_url directly
      let url = b.file_url;
      if (!url && b.file_uri) {
        const res = await base44.integrations.Core.CreateFileSignedUrl({ file_uri: b.file_uri, expires_in: 300 });
        url = res?.signed_url;
      }
      if (url) window.open(url, "_blank");
    } catch (e) { alert(e.message); } finally { setDownloading(null); }
  };

  const restore = async () => {
    if (!restoreItem) return;
    setRestoreLoading(true);
    try {
      const res = await base44.functions.invoke("restoreBackup", { file_uri: restoreItem.file_uri, file_url: restoreItem.file_url });
      if (res.data?.error) { alert(res.data.error); return; }
      const msg = `تمت الاستعادة بنجاح (${res.data.restored} سجل)${res.data.errors?.length ? ` مع ${res.data.errors.length} أخطاء` : ""}`;
      alert(msg);
      setRestoreItem(null);
    } catch (e) { alert(e.message); } finally { setRestoreLoading(false); }
  };

  if (loading) return <LoadingState />;

  return (
    <div>
      <PageHeader title="النسخ الاحتياطي والاستعادة" description="حماية بيانات الشبكة" action={
        <Button onClick={create} disabled={creating} className="gap-2"><DatabaseBackup className="w-4 h-4" /> {creating ? "جارٍ..." : "إنشاء نسخة"}</Button>
      } />

      {items.length === 0 ? (
        <EmptyState title="لا توجد نسخ احتياطية" description="أنشئ أول نسخة احتياطية لبياناتك" action={<Button onClick={create} className="gap-2"><DatabaseBackup className="w-4 h-4" /> إنشاء نسخة</Button>} />
      ) : (
        <Card className="divide-y divide-border">
          {items.map((b) => (
            <div key={b.id} className="flex items-center justify-between gap-2 p-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0"><DatabaseBackup className="w-5 h-5 text-primary" /></div>
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">{b.file_name}</p>
                  <p className="text-xs text-muted-foreground">{formatDateTime(b.created_date)} • {b.record_count} سجل {!b.file_uri && b.file_url ? "• عام (قديم)" : "• خاص"}</p>
                </div>
              </div>
              <div className="flex gap-1 shrink-0">
                <Button size="icon" variant="ghost" onClick={() => download(b)} disabled={downloading === b.id} className="text-blue-500 h-10 w-10"><Download className="w-4 h-4" /></Button>
                <Button size="icon" variant="ghost" onClick={() => setRestoreItem(b)} className="text-amber-500 h-10 w-10"><RotateCcw className="w-4 h-4" /></Button>
                <Button size="icon" variant="ghost" onClick={() => remove(b)} className="text-rose-500 h-10 w-10"><Trash2 className="w-4 h-4" /></Button>
              </div>
            </div>
          ))}
        </Card>
      )}

      <ConfirmDialog
        open={!!restoreItem}
        onOpenChange={(v) => !v && setRestoreItem(null)}
        title="استعادة نسخة احتياطية"
        description="تحذير: سيتم استبدال جميع البيانات الحالية بالبيانات من النسخة الاحتياطية مع الحفاظ على المعرّفات والعلاقات. لا يمكن التراجع. تأكد من عمل نسخة احتياطية للبيانات الحالية أولاً."
        confirmText="استعادة"
        destructive
        loading={restoreLoading}
        onConfirm={restore}
      />
    </div>
  );
}