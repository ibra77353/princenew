import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { StatCard, PageHeader, LoadingState, EmptyState } from "@/components/ui-shared";
import { Card } from "@/components/ui/card";
import { formatCurrency, formatDateTime, CASH_SOURCES } from "@/lib/format";
import { Wallet, TrendingUp, TrendingDown, ArrowDownToLine } from "lucide-react";
import PullToRefresh from "@/components/PullToRefresh";

export default function Cash() {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke("getCashSummary", {});
      setSummary(res.data);
    } catch (e) { console.error(e); } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  if (loading || !summary) return <LoadingState />;

  const sym = summary.settings?.currency_symbol || "ر.ي";
  const { opening, totalIn, totalOut, balance, bySource, transactions } = summary;
  const txns = transactions || [];

  const srcIn = (src) => bySource[src]?.in || 0;
  const srcOut = (src) => bySource[src]?.out || 0;

  return (
    <PullToRefresh onRefresh={load}>
    <div>
      <PageHeader title="الصندوق" description="رصيد الصندوق وحركاته المالية" />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        <StatCard title="الرصيد الحالي" value={formatCurrency(balance, sym)} icon={Wallet} tone="green" />
        <StatCard title="الرصيد الافتتاحي" value={formatCurrency(opening, sym)} icon={ArrowDownToLine} tone="primary" />
        <StatCard title="إجمالي المقبوضات" value={formatCurrency(totalIn, sym)} icon={TrendingUp} tone="green" />
        <StatCard title="إجمالي المدفوعات" value={formatCurrency(totalOut, sym)} icon={TrendingDown} tone="red" />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 gap-2.5 sm:gap-3 mb-5">
        <Card className="p-3"><p className="text-xs text-muted-foreground truncate">مقبوضات المبيعات</p><p className="font-bold text-emerald-600 text-sm sm:text-base truncate">{formatCurrency(srcIn("sale"), sym)}</p></Card>
        <Card className="p-3"><p className="text-xs text-muted-foreground truncate">التحصيلات</p><p className="font-bold text-emerald-600 text-sm sm:text-base truncate">{formatCurrency(srcIn("collection"), sym)}</p></Card>
        <Card className="p-3"><p className="text-xs text-muted-foreground truncate">المصروفات</p><p className="font-bold text-rose-500 text-sm sm:text-base truncate">{formatCurrency(srcOut("expense"), sym)}</p></Card>
        <Card className="p-3"><p className="text-xs text-muted-foreground truncate">دفعات الخطوط</p><p className="font-bold text-rose-500 text-sm sm:text-base truncate">{formatCurrency(srcOut("line_payment"), sym)}</p></Card>
        <Card className="p-3"><p className="text-xs text-muted-foreground truncate">سحوبات المالك</p><p className="font-bold text-rose-500 text-sm sm:text-base truncate">{formatCurrency(srcOut("owner_withdrawal"), sym)}</p></Card>
      </div>

      <h3 className="font-bold mb-3">سجل الحركات</h3>
      {txns.length === 0 ? <EmptyState title="لا توجد حركات" /> : (
        <Card className="divide-y divide-border">
          {txns.map((t) => (
            <div key={t.id} className="flex items-center justify-between gap-2 p-3">
              <div className="min-w-0">
                <p className="text-sm font-medium truncate">{t.description}</p>
                <p className="text-xs text-muted-foreground">{CASH_SOURCES[t.source] || t.source} • {formatDateTime(t.transaction_date)}</p>
              </div>
              <span className={`text-sm font-bold shrink-0 ${t.type === "in" ? "text-emerald-600" : "text-rose-500"}`}>
                {t.type === "in" ? "+" : "-"}{formatCurrency(t.amount, sym)}
              </span>
            </div>
          ))}
        </Card>
      )}
    </div>
    </PullToRefresh>
  );
}