import React, { useEffect, useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { PageHeader, LoadingState, EmptyState } from "@/components/ui-shared";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { DrawerSelect } from "@/components/DrawerSelect";
import { formatCurrency, formatDateTime } from "@/lib/format";
import { Plus, HandCoins, AlertCircle } from "lucide-react";
import Modal from "@/components/Modal";

export default function Collections() {
  const [items, setItems] = useState([]);
  const [distributors, setDistributors] = useState([]);
  const [cancelledSaleIds, setCancelledSaleIds] = useState(new Set());
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ distributor_id: "", sale_id: "", amount: "", notes: "" });
  const [distSales, setDistSales] = useState([]);
  const [loadingSales, setLoadingSales] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const [c, d, s] = await Promise.all([
        base44.entities.Collection.filter({}, { sort: "-collection_date", limit: 500 }),
        base44.entities.Distributor.filter({ status: "active" }),
        base44.entities.Sale.filter({ status: "cancelled" }, { limit: 500 })
      ]);
      setItems(Array.isArray(c) ? c : (c.items || []));
      setDistributors(Array.isArray(d) ? d : (d.items || []));
      const cancelled = Array.isArray(s) ? s : (s.items || []);
      setCancelledSaleIds(new Set(cancelled.map((sale) => sale.id)));
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  // When distributor changes, fetch their active sales with remaining > 0
  const onDistributorChange = async (distId) => {
    setForm({ ...form, distributor_id: distId, sale_id: "" });
    if (!distId) { setDistSales([]); return; }
    setLoadingSales(true);
    try {
      const res = await base44.entities.Sale.filter({ distributor_id: distId, status: "active" }, { sort: "-sale_date", limit: 200 });
      const sales = Array.isArray(res) ? res : (res.items || []);
      // Compute remaining per sale (total - paid - linked collections)
      const collectionsRes = await base44.entities.Collection.filter({ distributor_id: distId });
      const collections = Array.isArray(collectionsRes) ? collectionsRes : (collectionsRes.items || []);
      const salesWithRemaining = sales.map((s) => {
        const linked = collections.filter((c) => c.sale_id === s.id).reduce((a, c) => a + (Number(c.amount) || 0), 0);
        const remaining = (Number(s.total_amount) || 0) - (Number(s.paid_amount) || 0) - linked;
        return { ...s, computedRemaining: remaining };
      }).filter((s) => s.computedRemaining > 0);
      setDistSales(salesWithRemaining);
    } finally { setLoadingSales(false); }
  };

  const openNew = () => { setForm({ distributor_id: "", sale_id: "", amount: "", notes: "" }); setDistSales([]); setOpen(true); };

  const save = async () => {
    if (!form.distributor_id || !form.amount) return;
    setSaving(true);
    try {
      const dist = distributors.find((d) => d.id === form.distributor_id);
      const selectedSale = distSales.find((s) => s.id === form.sale_id);
      const res = await base44.functions.invoke("createCollection", {
        distributor_id: form.distributor_id,
        distributor_name: dist?.name || "",
        sale_id: form.sale_id || "",
        invoice_number: selectedSale?.invoice_number || "",
        amount: Number(form.amount),
        notes: form.notes
      });
      if (res.data?.error) { alert(res.data.error); return; }
      setOpen(false);
      load();
    } catch (e) { alert(e.message); } finally { setSaving(false); }
  };

  if (loading) return <LoadingState />;

  return (
    <div>
      <PageHeader title="التحصيلات" description="تحصيل الأموال من الموزعين" action={
        <Button onClick={openNew} className="gap-2"><Plus className="w-4 h-4" /> تحصيل جديد</Button>
      } />
      {items.length === 0 ? (
        <EmptyState title="لا توجد تحصيلات" action={<Button onClick={openNew} className="gap-2"><Plus className="w-4 h-4" /> تسجيل تحصيل</Button>} />
      ) : (
        <Card className="divide-y divide-border">
          {items.map((c) => {
            const isCancelled = c.sale_id && cancelledSaleIds.has(c.sale_id);
            return (
              <div key={c.id} className="flex items-center justify-between gap-2 p-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium flex items-center gap-1.5">
                    {c.distributor_name}
                    {isCancelled && (
                      <span className="inline-flex items-center gap-1 text-[10px] font-medium text-rose-600 bg-rose-500/10 px-1.5 py-0.5 rounded-full">
                        <AlertCircle className="w-3 h-3" /> فاتورة ملغاة
                      </span>
                    )}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {formatDateTime(c.collection_date)}
                    {c.invoice_number ? ` • ${c.invoice_number}` : ""}
                    {c.notes ? ` • ${c.notes}` : ""}
                  </p>
                </div>
                <span className={`text-sm font-bold shrink-0 ${isCancelled ? "text-rose-500 line-through" : "text-emerald-600"}`}>
                  {isCancelled ? "-" : "+"}{formatCurrency(c.amount)}
                </span>
              </div>
            );
          })}
        </Card>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="تسجيل تحصيل" icon={HandCoins}>
        <div className="space-y-3">
              <div><Label>الموزع</Label>
                <DrawerSelect
                  value={form.distributor_id}
                  onValueChange={onDistributorChange}
                  placeholder="اختر الموزع"
                  options={distributors.map((d) => ({ value: d.id, label: d.name }))}
                />
              </div>
              <div><Label>الفاتورة (اختياري)</Label>
                <DrawerSelect
                  value={form.sale_id}
                  onValueChange={(v) => setForm({ ...form, sale_id: v })}
                  placeholder={loadingSales ? "جارٍ التحميل..." : "تحصيل عام (بدون فاتورة)"}
                  options={distSales.map((s) => ({ value: s.id, label: `${s.invoice_number} — متبقي ${formatCurrency(s.computedRemaining)}` }))}
                />
                {form.distributor_id && distSales.length === 0 && !loadingSales && (
                  <p className="text-xs text-muted-foreground mt-1">لا توجد فواتير مستحقة لهذا الموزع</p>
                )}
              </div>
              <div><Label>المبلغ</Label><Input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></div>
              <div><Label>ملاحظات</Label><Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={2} /></div>
          <div className="flex flex-col-reverse sm:flex-row gap-2 sm:justify-end pt-2">
            <Button variant="outline" onClick={() => setOpen(false)} className="h-11 sm:h-9">إلغاء</Button>
            <Button onClick={save} disabled={saving} className="h-11 sm:h-9">{saving ? "جارٍ..." : "تأكيد"}</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}