import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
import Layout from '@/components/Layout';
import Dashboard from '@/pages/Dashboard';
import Packages from '@/pages/Packages';
import Inventory from '@/pages/Inventory';
import Distributors from '@/pages/Distributors';
import DistributorDetail from '@/pages/DistributorDetail';
import Sales from '@/pages/Sales';
import Collections from '@/pages/Collections';
import Lines from '@/pages/Lines';
import LineDetail from '@/pages/LineDetail';
import LinePayments from '@/pages/LinePayments';
import Expenses from '@/pages/Expenses';
import OwnerWithdrawals from '@/pages/OwnerWithdrawals';
import Cash from '@/pages/Cash';
import Reports from '@/pages/Reports';
import SearchPage from '@/pages/Search';
import AuditLog from '@/pages/AuditLog';
import SettingsPage from '@/pages/Settings';
import BackupPage from '@/pages/Backup';
import Login from '@/pages/Login';

import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/login" element={<Login />} />

      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route element={<Layout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/packages" element={<Packages />} />
          <Route path="/inventory" element={<Inventory />} />
          <Route path="/distributors" element={<Distributors />} />
          <Route path="/distributors/:id" element={<DistributorDetail />} />
          <Route path="/sales" element={<Sales />} />
          <Route path="/collections" element={<Collections />} />
          <Route path="/lines" element={<Lines />} />
          <Route path="/lines/:id" element={<LineDetail />} />
          <Route path="/line-payments" element={<LinePayments />} />
          <Route path="/expenses" element={<Expenses />} />
          <Route path="/owner-withdrawals" element={<OwnerWithdrawals />} />
          <Route path="/cash" element={<Cash />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/search" element={<SearchPage />} />
          <Route path="/audit" element={<AuditLog />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/backup" element={<BackupPage />} />
        </Route>
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App