import React from "react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Modal({ open, onClose, title, icon: Icon, children, maxWidth = "max-w-md", footer }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4 bg-black/50" onClick={onClose}>
      <div
        className={cn(
          "w-full bg-card text-card-foreground rounded-t-2xl sm:rounded-2xl shadow-xl",
          "max-h-[92vh] overflow-y-auto scrollbar-thin",
          "animate-in slide-in-from-bottom-4 sm:slide-in-from-bottom-0 sm:zoom-in-95 duration-200",
          maxWidth
        )}
        style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Mobile drag handle */}
        <div className="sm:hidden flex justify-center pt-2.5 pb-1">
          <div className="w-10 h-1 rounded-full bg-muted-foreground/30" />
        </div>
        {title && (
          <div className="flex items-center justify-between px-5 pt-3 sm:pt-4 pb-3 border-b border-border sticky top-0 bg-card z-10 rounded-t-2xl">
            <h3 className="font-bold text-lg flex items-center gap-2">
              {Icon && <Icon className="w-5 h-5" />}
              {title}
            </h3>
            <button onClick={onClose} className="text-muted-foreground hover:text-foreground p-1.5 -mt-1 -me-1.5 rounded-lg hover:bg-accent">
              <X className="w-5 h-5" />
            </button>
          </div>
        )}
        <div className="p-5">
          {children}
        </div>
      </div>
    </div>
  );
}