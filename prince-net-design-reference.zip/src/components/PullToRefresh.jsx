import React, { useState, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";

const THRESHOLD = 70;
const MAX_PULL = 100;
const RESISTANCE = 0.5;

/**
 * Pull-to-refresh wrapper: detects a swipe-down gesture at the top of the
 * page, shows a spinner, and triggers react-query invalidation plus an
 * optional onRefresh callback. Only activates on touch devices when
 * scrollTop is 0.
 */
export default function PullToRefresh({ children, onRefresh, className }) {
  const queryClient = useQueryClient();
  const [pullDistance, setPullDistance] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const startYRef = useRef(0);
  const pullingRef = useRef(false);

  const handleTouchStart = (e) => {
    if (window.scrollY > 0 || refreshing) return;
    startYRef.current = e.touches[0].clientY;
    pullingRef.current = true;
  };

  const handleTouchMove = (e) => {
    if (!pullingRef.current || refreshing) return;
    const diff = e.touches[0].clientY - startYRef.current;
    if (diff > 0 && window.scrollY <= 0) {
      setPullDistance(Math.min(diff * RESISTANCE, MAX_PULL));
    } else {
      pullingRef.current = false;
      setPullDistance(0);
    }
  };

  const handleTouchEnd = async () => {
    if (!pullingRef.current) return;
    pullingRef.current = false;
    if (pullDistance >= THRESHOLD) {
      setRefreshing(true);
      setPullDistance(THRESHOLD);
      try {
        await Promise.all([
          queryClient.invalidateQueries(),
          onRefresh?.(),
        ]);
      } finally {
        setRefreshing(false);
        setPullDistance(0);
      }
    } else {
      setPullDistance(0);
    }
  };

  const progress = Math.min(pullDistance / THRESHOLD, 1);

  return (
    <div
      className={className}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      <div
        className="flex items-center justify-center overflow-hidden transition-all duration-200"
        style={{ height: pullDistance }}
      >
        <Loader2
          className={`text-primary ${refreshing ? "animate-spin" : ""}`}
          style={{
            width: 24,
            height: 24,
            ...(refreshing
              ? {}
              : { transform: `rotate(${progress * 360}deg)`, opacity: progress }),
          }}
        />
      </div>
      {children}
    </div>
  );
}